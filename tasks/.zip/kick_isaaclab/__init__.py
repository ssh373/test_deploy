"""MuJoCo deployment registration for the Isaac Lab K1 kick policy."""

from booster_deploy.utils.isaaclab.configclass import configclass
from booster_deploy.utils.registry import register_task

from .kick_k1 import K1IsaacLabKickControllerCfg


@configclass
class K1IsaacLabKickDeployCfg(K1IsaacLabKickControllerCfg):
    def __post_init__(self):
        super().__post_init__()
        self.policy.checkpoint_path = "models/k1_kick_jit.pt"


register_task("k1_kick_isaaclab", K1IsaacLabKickDeployCfg())
