# K1 Isaac Lab kick policy in MuJoCo

This task deploys the 49-dimensional actor trained with
`Booster-K1-Kick_001-v0`. It is separate from the older
`tasks/locomotion/kick_k1.py`, whose observation contract is incompatible.

## Model

Export the RSL-RL policy from Isaac Lab, then copy the TorchScript file to:

```text
tasks/kick_isaaclab/models/k1_kick_jit.pt
```

The actor contract is:

```text
gravity(3), base angular velocity(3), ball relative XY(2),
target relative XY * 0.25(2), visible/age/confidence(3),
joint position error(12), joint velocity * 0.1(12), last action(12)
```

Ball velocity is not included in the actor observation.

## Run

From the `deploy` directory:

```bash
python scripts/deploy.py --task k1_kick_isaaclab --mujoco
```

The default ball is 0.275 m in front of the robot and the target is 4 m ahead.
For a directional test, change `target_angle_deg` in `K1IsaacLabKickPolicyCfg`
to a value between -60 and +60 degrees.

The task owns its MJCF at `assets/K1_22dof_kick_ball.xml`. Its compiler line
expects K1 meshes at `/home/user/booster_assets/robots/K1/meshes`; update only
that `meshdir` if the Booster assets live elsewhere on the deployment machine.
